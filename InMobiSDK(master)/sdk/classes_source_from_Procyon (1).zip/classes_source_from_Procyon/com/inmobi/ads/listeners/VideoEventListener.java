// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.ads.listeners;

import com.inmobi.ads.InMobiNative;

public abstract class VideoEventListener
{
    public void onVideoCompleted(final InMobiNative inMobiNative) {
    }
    
    public void onVideoSkipped(final InMobiNative inMobiNative) {
    }
    
    public void onAudioStateChanged(final InMobiNative inMobiNative, final boolean b) {
    }
}
