// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.commons.utils.json;

import androidx.annotation.NonNull;

public interface Constructor<T>
{
    @NonNull
    T construct();
}
