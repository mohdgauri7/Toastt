// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public class hj
{
    private static final String a;
    private static boolean b;
    
    public static void a(final boolean b) {
        hj.b = b;
    }
    
    public static void a() {
    }
    
    static {
        a = hj.class.getName();
        hj.b = false;
    }
}
