// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import org.json.JSONArray;
import java.util.List;

public final class bb extends ak
{
    public final String a;
    public final String b;
    public final String c;
    public final List<bv> d;
    public final List<cw> e;
    
    bb(final ak ak, final JSONArray jsonArray, final String a, final String b, final String c, final List<bv> d, final List<cw> e) {
        super(ak, jsonArray);
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
}
