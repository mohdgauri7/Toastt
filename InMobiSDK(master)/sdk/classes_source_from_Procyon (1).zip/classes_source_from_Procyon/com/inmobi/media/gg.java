// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class gg
{
    private static final String a;
    private gm b;
    private a c;
    
    public gg(final gm b, final a c) {
        this.b = b;
        this.c = c;
    }
    
    static {
        a = gg.class.getSimpleName();
    }
    
    public interface a
    {
        void a(final gn p0);
        
        void a();
    }
}
