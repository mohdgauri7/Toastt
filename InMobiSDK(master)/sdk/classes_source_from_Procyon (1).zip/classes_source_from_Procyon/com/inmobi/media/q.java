// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import java.util.Map;
import androidx.annotation.NonNull;
import java.util.HashMap;

public abstract class q
{
    private static final String a;
    
    public void c(final o o) {
    }
    
    public void d(final o o) {
    }
    
    public void e(final o o) {
    }
    
    public void f(final o o) {
    }
    
    public void a() {
    }
    
    public void a_(final o o) {
    }
    
    public void b_(final o o) {
    }
    
    public void g(final o o) {
    }
    
    public void b(@NonNull final HashMap<Object, Object> hashMap) {
    }
    
    public void a(@NonNull final HashMap<Object, Object> hashMap) {
    }
    
    public void a_() {
    }
    
    public void a(final String s, final Map<String, Object> map) {
    }
    
    public void d_() {
    }
    
    public void f() {
    }
    
    public void g() {
    }
    
    public void h(final o o) {
    }
    
    public void i(final o o) {
    }
    
    public abstract it c_();
    
    static {
        a = q.class.getSimpleName();
    }
}
