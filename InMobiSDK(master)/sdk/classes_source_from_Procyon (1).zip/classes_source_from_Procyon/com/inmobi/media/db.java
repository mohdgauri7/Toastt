// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.UiThread;

public interface db
{
    @UiThread
    void a(final ak p0, final boolean p1, final byte p2);
}
