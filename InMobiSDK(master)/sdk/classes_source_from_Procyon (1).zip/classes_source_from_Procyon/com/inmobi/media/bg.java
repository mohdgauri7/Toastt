// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class bg extends Exception
{
    public bg(final String message) {
        super(message);
    }
}
