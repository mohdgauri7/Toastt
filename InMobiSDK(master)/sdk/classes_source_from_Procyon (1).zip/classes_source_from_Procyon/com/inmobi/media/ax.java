// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public interface ax
{
    void a(final am p0, final byte p1);
    
    void a(final am p0);
}
