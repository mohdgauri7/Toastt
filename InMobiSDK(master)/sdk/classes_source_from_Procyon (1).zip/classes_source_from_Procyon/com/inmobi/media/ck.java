// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import android.content.Context;

public class ck
{
    private static final String c;
    public String a;
    private int d;
    private int e;
    public gm b;
    private long f;
    
    public ck(final String a, final int d, final int e, final long f) {
        this.a = a;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    static {
        c = ck.class.getSimpleName();
    }
}
