// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class ij
{
    int a;
    int b;
    int c;
    int d;
    String e;
    
    public ij() {
        this.a = -1;
        this.b = -1;
        this.c = -1;
        this.d = -1;
    }
}
