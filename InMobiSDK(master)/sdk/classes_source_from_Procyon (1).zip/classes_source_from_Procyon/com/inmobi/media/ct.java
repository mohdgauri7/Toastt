// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.UiThread;

public interface ct
{
    @UiThread
    void c(final byte p0);
    
    @UiThread
    void d(final byte p0);
}
