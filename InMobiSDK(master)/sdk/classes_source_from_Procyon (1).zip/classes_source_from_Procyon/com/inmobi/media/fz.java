// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class fz
{
    long a;
    public String b;
    long c;
    int d;
    public String e;
    long f;
    int g;
    private int k;
    long h;
    int i;
    private int l;
    long j;
    
    public fz(final int d, final long a, final long f, final long c, final int g, final int k, final int i, final int l, final long h, final long j) {
        this.a = a;
        this.c = c;
        this.d = d;
        this.f = f;
        this.g = g;
        this.k = k;
        this.h = h;
        this.i = i;
        this.l = l;
        this.j = j;
    }
}
