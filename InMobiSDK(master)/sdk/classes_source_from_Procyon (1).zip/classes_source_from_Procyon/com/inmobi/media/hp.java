// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class hp
{
    public int a;
    public int b;
    public float c;
    
    public hp(final int a, final int b, final float c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
