// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class fa extends fd<o>
{
    public fa(final o o, final long n) {
        super(o, n);
    }
    
    @Override
    public final void a(final o o) {
        if (o != null) {
            o.i();
        }
    }
}
