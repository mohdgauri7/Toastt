// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public interface av
{
    void a(final gn p0, final String p1, final al p2);
    
    void a(final al p0);
}
