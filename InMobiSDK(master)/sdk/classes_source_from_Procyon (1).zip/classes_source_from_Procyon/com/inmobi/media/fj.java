// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

final class fj
{
    @NonNull
    ff a;
    @Nullable
    fg.c b;
    
    fj(@NonNull final ff a, @Nullable final fg.c b) {
        this.a = a;
        this.b = b;
    }
}
