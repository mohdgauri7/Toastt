// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.NonNull;

public abstract class df extends dg
{
    protected df(@NonNull final h h) {
        super(h);
    }
}
