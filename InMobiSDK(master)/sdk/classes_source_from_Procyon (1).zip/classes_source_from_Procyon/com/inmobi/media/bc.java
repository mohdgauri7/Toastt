// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import java.util.Map;

public final class bc
{
    public long a;
    public String b;
    public Map<String, String> c;
    public boolean d;
    public String e;
    public String f;
}
