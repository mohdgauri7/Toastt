// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class bp extends bj
{
    public bp(final String s, final String s2, final bk bk, final String e) {
        super(s, s2, "ICON", bk);
        this.e = e;
    }
}
