// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.NonNull;

public final class ca
{
    @NonNull
    public t a;
    
    public ca(@NonNull final t a) {
        this.a = a;
    }
}
