// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class bt extends bj
{
    public boolean z;
    public bs A;
    
    public bt(final String s, final String s2, final bk bk, final bs a) {
        super(s, s2, "TIMER", bk);
        this.A = a;
    }
}
