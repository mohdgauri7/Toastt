// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

final class fi
{
    private byte a;
    private String b;
    
    fi(final byte a, final String b) {
        this.a = a;
        this.b = b;
    }
}
