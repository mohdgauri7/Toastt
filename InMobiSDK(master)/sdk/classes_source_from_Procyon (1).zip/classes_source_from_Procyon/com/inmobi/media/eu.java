// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public interface eu
{
    void destroy();
}
