// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.NonNull;
import java.util.List;

public final class gb
{
    final List<Integer> a;
    final String b;
    final boolean c;
    
    public gb(@NonNull final List<Integer> a, @NonNull final String b) {
        this.a = a;
        this.b = b;
        this.c = false;
    }
}
