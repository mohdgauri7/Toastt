// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.NonNull;

public interface y
{
    void a(final String p0, final String p1);
    
    void a(final String p0, final String p1, @NonNull final j p2, final String p3);
}
