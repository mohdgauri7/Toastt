// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public class ht
{
    private static final String e;
    public String a;
    public long b;
    public long c;
    public boolean d;
    
    public static ht a() {
        return a.a;
    }
    
    private ht() {
    }
    
    static {
        e = ht.class.getSimpleName();
    }
    
    static final class a
    {
        static final ht a;
        
        static {
            a = new ht((byte)0);
        }
    }
}
