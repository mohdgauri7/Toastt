// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import java.util.Map;

public interface be
{
    void b(final String p0, final Map<String, Object> p1);
}
