// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import java.util.List;

public abstract class ga
{
    public abstract void a(final List<Integer> p0);
    
    public abstract int a();
    
    public abstract void b(final long p0);
    
    public abstract void c(final long p0);
    
    public abstract long c();
    
    public abstract boolean a(final long p0);
    
    public abstract boolean a(final long p0, final long p1);
}
