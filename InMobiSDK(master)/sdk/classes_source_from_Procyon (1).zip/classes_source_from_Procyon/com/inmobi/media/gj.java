// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public interface gj<T>
{
    void a(final T p0);
    
    void a(final gl p0);
}
