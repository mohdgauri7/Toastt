// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

@hw
public final class fp
{
    public boolean O1;
    public boolean UM5;
    public boolean GPID;
    
    fp() {
        this.O1 = true;
        this.UM5 = true;
        this.GPID = true;
    }
}
