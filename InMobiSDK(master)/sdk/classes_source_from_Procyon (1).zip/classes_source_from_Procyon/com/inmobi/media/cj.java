// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.Nullable;
import android.view.ViewGroup;
import androidx.annotation.NonNull;

public final class cj
{
    private static final String e;
    @NonNull
    public o a;
    public boolean b;
    @Nullable
    public ViewGroup c;
    public int d;
    
    public cj(@NonNull final o a) {
        this.a = a;
        this.b = false;
    }
    
    static {
        e = cj.class.getSimpleName();
    }
}
