// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class gl
{
    public int a;
    public String b;
    
    public gl(final int a, final String b) {
        this.a = a;
        this.b = b;
    }
}
