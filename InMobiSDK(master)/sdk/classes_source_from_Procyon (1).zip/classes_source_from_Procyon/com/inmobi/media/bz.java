// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public final class bz
{
    @NonNull
    public t a;
    @Nullable
    public ca b;
    
    public bz(@NonNull final t a) {
        this.a = a;
    }
}
