// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public interface j
{
    void a(final String p0, final String p1, final String p2);
}
