// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class bh extends Exception
{
    public int a;
    public byte b;
    
    public bh(final int a) {
        this.a = a;
    }
}
