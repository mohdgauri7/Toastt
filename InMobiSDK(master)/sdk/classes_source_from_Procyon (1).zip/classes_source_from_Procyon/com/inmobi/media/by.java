// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class by
{
    public String a;
    public boolean b;
    
    public by(final String a, final boolean b) {
        this.a = null;
        this.b = false;
        this.a = a;
        this.b = b;
    }
    
    public by() {
        this.a = null;
        this.b = false;
    }
}
