// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public final class cx
{
    String a;
    private String d;
    private String e;
    int b;
    double c;
    
    cx(final String s) {
        this(s, null, null, 1000);
    }
    
    cx(final String a, final String d, final String e, final int b) {
        this.a = a;
        this.d = d;
        this.e = e;
        this.b = b;
    }
}
