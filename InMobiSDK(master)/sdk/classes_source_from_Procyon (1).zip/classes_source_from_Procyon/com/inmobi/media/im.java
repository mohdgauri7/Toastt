// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

public class im
{
    private static final String e;
    public long a;
    String b;
    int c;
    int d;
    
    static {
        e = im.class.getSimpleName();
    }
}
