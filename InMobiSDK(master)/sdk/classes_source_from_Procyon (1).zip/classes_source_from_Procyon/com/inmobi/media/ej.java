// 
// Decompiled by Procyon v0.5.36
// 

package com.inmobi.media;

import android.graphics.Canvas;

public interface ej
{
    void a();
    
    void a(final boolean p0);
    
    int b();
    
    int c();
    
    void a(final Canvas p0, final float p1, final float p2);
    
    boolean d();
    
    void e();
    
    void a(final a p0);
    
    public interface a
    {
        void a();
    }
}
