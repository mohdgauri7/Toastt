package android.support.v7.content.res;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;

public class AppCompatResources {
  public static ColorStateList getColorStateList(final Context context, final int resId) {
    throw new RuntimeException("Stub!");
  }
  
  public static Drawable getDrawable(final Context context, final int resId) {
    throw new RuntimeException("Stub!");
  }
}