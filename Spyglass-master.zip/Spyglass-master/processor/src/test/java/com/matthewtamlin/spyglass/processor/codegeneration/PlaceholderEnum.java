package com.matthewtamlin.spyglass.processor.codegeneration;

public enum PlaceholderEnum {}